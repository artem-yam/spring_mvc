create view SALES_BY_CATEGORY as
SELECT Categories.CategoryID, Categories.CategoryName, Products.ProductName,
	Sum(Order_Details_Extended.ExtendedPrice) AS ProductSales
FROM 	Categories INNER JOIN
		(Products INNER JOIN
			(Orders INNER JOIN Order_Details_Extended ON Orders.OrderID = Order_Details_Extended.OrderID)
		ON Products.ProductID = Order_Details_Extended.ProductID)
	ON Categories.CategoryID = Products.CategoryID
WHERE Orders.OrderDate BETWEEN '19970101' And '19971231'
GROUP BY Categories.CategoryID, Categories.CategoryName, Products.ProductName
/

