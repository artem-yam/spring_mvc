create view PRODUCT_SALES_FOR_1997 as
SELECT Categories.CategoryName, Products.ProductName,
Sum(((Order_Details.UnitPrice*Quantity*(1-Discount)/100))*100) AS ProductSales
FROM (Categories INNER JOIN Products ON Categories.CategoryID = Products.CategoryID)
    INNER JOIN (Orders
        INNER JOIN Order_Details ON Orders.OrderID = Order_Details.OrderID)
    ON Products.ProductID = Order_Details.ProductID
WHERE (((Orders.ShippedDate) Between '19970101' And '19971231'))
GROUP BY Categories.CategoryName, Products.ProductName
/

