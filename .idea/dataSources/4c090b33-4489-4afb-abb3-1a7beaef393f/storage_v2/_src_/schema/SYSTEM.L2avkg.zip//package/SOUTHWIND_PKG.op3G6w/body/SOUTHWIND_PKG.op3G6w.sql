create Package Body SouthWind_PKG AS
Procedure CustOrdersDetail (p_OrderID in integer, io_Cursor out t_cursor)
Is
    v_cursor t_cursor;
Begin
    Open v_cursor For
        SELECT ProductName,
            ROUND(Od.UnitPrice, 2) as UnitPrice,
            Quantity,
            Floor(Discount * 100) as Discount,
            ROUND((Quantity * (1 - Discount) * Od.UnitPrice), 2) as ExtendedPrice
        FROM Products P, Order_Details Od
        WHERE Od.ProductID = P.ProductID and Od.OrderID = p_OrderID;
        io_cursor := v_cursor;
End CustOrdersDetail;

Procedure CustOrdersOrders (p_CustomerID in char, io_cursor out t_cursor)
Is
    v_cursor t_cursor;
Begin
    Open v_cursor For
        SELECT OrderID,
            OrderDate,
            RequiredDate,
            ShippedDate
        FROM Orders
        WHERE CustomerID = p_CustomerID
        ORDER BY OrderID;
    io_cursor := v_cursor;
End CustOrdersOrders;


Procedure CustOrderHist(p_CustomerID char, io_cursor out t_cursor)
Is
    v_cursor t_cursor;
Begin
    open v_cursor for
        SELECT ProductName,
               SUM(Quantity) as Total
        FROM Products P, Order_Details OD, Orders O, Customers C
        WHERE C.CustomerID = p_CustomerID
        AND C.CustomerID = O.CustomerID AND O.OrderID = OD.OrderID AND OD.ProductID = P.ProductID
        GROUP BY ProductName;
    io_cursor := v_cursor;
End CustOrderHist;

Procedure SalesByCategory
    (p_CategoryName in varchar2, i_OrdYear varchar2 := '1998', io_cursor out t_cursor)
Is
    v_cursor t_cursor;
    p_OrdYear varchar2(5) := i_OrdYear;
Begin
    If p_OrdYear <> '1996' and p_OrdYear <> '1997' and p_OrdYear <> '1998' Then
        p_OrdYear := '1998';
    End If;

    Open v_cursor for
        SELECT ProductName,
            ROUND(SUM((OD.Quantity * (1-OD.Discount) * OD.UnitPrice)), 0) as TotalPurchase
        FROM Order_Details OD, Orders O, Products P, Categories C
        WHERE OD.OrderID = O.OrderID
            AND OD.ProductID = P.ProductID
            AND P.CategoryID = C.CategoryID
            AND Upper(C.CategoryName) = Upper(p_CategoryName)
            AND TO_CHAR(O.OrderDate, 'YYYY') = p_OrdYear
        GROUP BY ProductName
        ORDER BY ProductName;

    io_cursor := v_cursor;
End SalesByCategory ;

procedure TenMostExpensiveProducts (io_cursor out t_cursor)
is
    v_cursor t_cursor;
Begin
    Open v_cursor for
        SELECT Products.ProductName AS TenMostExpensiveProducts, Products.UnitPrice
        FROM Products
        ORDER BY Products.UnitPrice DESC;

    io_cursor := v_cursor;
End TenMostExpensiveProducts;

Procedure EmployeeSalesByCountry (Beginning_Date in date, Ending_date in date, io_cursor out t_cursor)
Is
    v_cursor t_cursor;
Begin
    Open v_cursor for
        SELECT Employees.Country, Employees.LastName, Employees.FirstName, Orders.ShippedDate, Orders.OrderID, Order_Subtotals.Subtotal AS SaleAmount
        FROM Employees INNER JOIN
            (Orders INNER JOIN Order_Subtotals ON Orders.OrderID = Order_Subtotals.OrderID)
            ON Employees.EmployeeID = Orders.EmployeeID
        WHERE Orders.ShippedDate Between Beginning_Date And Ending_Date;

        io_cursor := v_cursor;
End EmployeeSalesByCountry ;

Procedure SalesByYear (Beginning_Date in  Date, Ending_Date in  Date, io_cursor out t_cursor)
Is
    v_cursor t_cursor;
Begin
    Open v_cursor for
        SELECT Orders.ShippedDate, Orders.OrderID, Order_Subtotals.Subtotal, TO_CHAR(ShippedDate, 'YYYY') AS Year
        FROM Orders INNER JOIN Order_Subtotals ON Orders.OrderID = Order_Subtotals.OrderID
        WHERE Orders.ShippedDate Between Beginning_Date And Ending_Date;

    io_cursor := v_cursor;
End SalesByYear;
End SouthWind_PKG;
/

