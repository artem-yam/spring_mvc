create view ALPHABETICAL_LIST_OF_PRODUCTS as
SELECT Products."PRODUCTID",Products."PRODUCTNAME",Products."SUPPLIERID",Products."CATEGORYID",Products."QUANTITYPERUNIT",Products."UNITPRICE",Products."UNITSINSTOCK",Products."UNITSONORDER",Products."REORDERLEVEL",Products."DISCONTINUED", Categories.CategoryName
FROM Categories INNER JOIN Products ON Categories.CategoryID = Products.CategoryID
WHERE (((Products.Discontinued)=0))
/

