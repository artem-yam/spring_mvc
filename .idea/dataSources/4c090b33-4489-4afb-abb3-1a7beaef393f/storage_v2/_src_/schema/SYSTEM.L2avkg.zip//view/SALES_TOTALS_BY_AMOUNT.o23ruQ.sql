create view SALES_TOTALS_BY_AMOUNT as
SELECT Order_Subtotals.Subtotal AS SaleAmount, Orders.OrderID, Customers.CompanyName, Orders.ShippedDate
FROM 	Customers INNER JOIN
		(Orders INNER JOIN Order_Subtotals ON Orders.OrderID = Order_Subtotals.OrderID)
	ON Customers.CustomerID = Orders.CustomerID
WHERE (Order_Subtotals.Subtotal >2500) AND (Orders.ShippedDate BETWEEN '19970101' And '19971231')
/

