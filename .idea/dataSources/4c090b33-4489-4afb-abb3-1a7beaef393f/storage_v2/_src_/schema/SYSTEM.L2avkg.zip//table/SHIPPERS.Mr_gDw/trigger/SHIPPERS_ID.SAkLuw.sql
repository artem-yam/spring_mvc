create trigger SHIPPERS_ID
    before insert
    on SHIPPERS
    for each row
DECLARE
tmpVar NUMBER;
BEGIN
   tmpVar := 0;

   SELECT Shippers_Seq.NEXTVAL INTO tmpVar FROM dual;
   :NEW.ShipperID := tmpVar;

END Shippers_Id;
/

