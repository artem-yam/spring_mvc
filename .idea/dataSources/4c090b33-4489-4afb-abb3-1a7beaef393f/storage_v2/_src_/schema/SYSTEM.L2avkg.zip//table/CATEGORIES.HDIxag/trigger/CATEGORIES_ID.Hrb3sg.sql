create trigger CATEGORIES_ID
    before insert
    on CATEGORIES
    for each row
DECLARE
tmpVar NUMBER;
BEGIN
   tmpVar := 0;

   SELECT categories_Seq.NEXTVAL INTO tmpVar FROM dual;
   :NEW.CategoryID := tmpVar;

END Categories_Id;
/

