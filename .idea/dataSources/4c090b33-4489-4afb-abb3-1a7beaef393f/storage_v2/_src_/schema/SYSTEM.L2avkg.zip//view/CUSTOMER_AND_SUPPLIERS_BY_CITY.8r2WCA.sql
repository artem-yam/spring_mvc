create view CUSTOMER_AND_SUPPLIERS_BY_CITY as
    SELECT City, CompanyName, ContactName, 'Customers' AS Relationship
FROM Customers
UNION SELECT City, CompanyName, ContactName, 'Suppliers'
FROM Suppliers
/

