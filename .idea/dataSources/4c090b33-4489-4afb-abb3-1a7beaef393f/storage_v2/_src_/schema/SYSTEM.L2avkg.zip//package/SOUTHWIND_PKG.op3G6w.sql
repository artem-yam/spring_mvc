create Package SouthWind_PKG AS
    Type t_cursor is ref cursor;
Procedure CustOrdersDetail(p_OrderID in integer, io_cursor out t_cursor);
PROCEDURE CustOrdersOrders (p_CustomerID in char, io_cursor out t_cursor);
Procedure CustOrderHist(p_CustomerID char, io_cursor out t_cursor);
Procedure SalesByCategory (p_CategoryName in varchar2, i_OrdYear varchar2 := '1998', io_cursor out t_cursor);
Procedure TenMostExpensiveProducts (io_cursor out t_cursor);
Procedure EmployeeSalesByCountry (Beginning_Date in date, Ending_date in date, io_cursor out t_cursor);
Procedure SalesByYear (Beginning_Date in  Date, Ending_Date in  Date, io_cursor out t_cursor);
End SouthWind_PKG;
/

