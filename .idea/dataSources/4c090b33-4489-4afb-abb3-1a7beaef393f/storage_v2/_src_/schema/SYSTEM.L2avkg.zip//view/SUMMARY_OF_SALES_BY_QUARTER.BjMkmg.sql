create view SUMMARY_OF_SALES_BY_QUARTER as
SELECT Orders.ShippedDate, Orders.OrderID, Order_Subtotals.Subtotal
FROM Orders INNER JOIN Order_Subtotals ON Orders.OrderID = Order_Subtotals.OrderID
WHERE Orders.ShippedDate IS NOT NULL
/

