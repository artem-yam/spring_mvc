create trigger EMPLOYEES_ID
    before insert
    on EMPLOYEES
    for each row
DECLARE
tmpVar NUMBER;
BEGIN
   tmpVar := 0;

   SELECT Employees_Seq.NEXTVAL INTO tmpVar FROM dual;
   :NEW.EmployeeId := tmpVar;

END Employees_Id;
/

