create view CURRENT_PRODUCT_LIST as
SELECT ProductID, ProductName
FROM Products
WHERE (((Discontinued)=0))
/

