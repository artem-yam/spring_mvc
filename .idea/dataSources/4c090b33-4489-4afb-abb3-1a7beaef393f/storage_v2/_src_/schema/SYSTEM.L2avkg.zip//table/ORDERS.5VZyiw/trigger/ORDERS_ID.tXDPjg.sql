create trigger ORDERS_ID
    before insert
    on ORDERS
    for each row
DECLARE
tmpVar NUMBER;
BEGIN
   tmpVar := 0;

   SELECT Orders_Seq.NEXTVAL INTO tmpVar FROM dual;
   :NEW.OrderID := tmpVar;

END Orders_Id;
/

